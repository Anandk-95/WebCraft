let progress =  document.getElementById("progress"); // This line retrieves an HTML 
//element with the ID "progress" and assigns it to a variable named progress.
let song = document.getElementById("song"); // same as a previous line
let ctrlIcon = document.getElementById("ctrlIcon"); // same as a previous two line

song.onloadedmetadata = function(){ //event occur when meta data for media has been loaded
    progress.max = song.duration; 
    progress.value = song.currentTime; 
}

function playPause(){
    if(ctrlIcon.classList.contains("fa-pause")){
        song.pause();
        ctrlIcon.classList.remove("fa-pause");
        ctrlIcon.classList.add("fa-play");
    }
    else{
        song.play();
        ctrlIcon.classList.add("fa-pause");
        ctrlIcon.classList.remove("fa-play");
    }
}
    if(song.play()){
        setInterval(()=>{
            progress.value = song.currentTime;
        },500);
    }

    progress.onchange = function(){
        song.play();
        song.currentTime = progress.value;
        ctrlIcon.classList.add("fa-pause");
        ctrlIcon.classList.remove("fa-play");
        
    }